function ave=averageIntensity()

    
    Img=imread('Fig_blurry_moon.tif');
    ave=sum(Img(:))/length(Img(:))

end