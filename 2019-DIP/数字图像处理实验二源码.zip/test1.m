%%  ��ʼ��
clc
clear all
close all

%%  ����ͼ��
img1=imread('Fig_DFT_no_log.tif');
figure;
subplot(1,2,1);
imshow(img1);
imwrite(img1,'original.bmp');
title('original');

%%  the log transformation of Eq.: s = clog (1 + r)
c=input('input c is��');
t1=c*log(1+double(img1));
t2=mat2gray(t1);            %�����һ��

t3=im2uint8(t2);
subplot(1,2,2);
imshow(t3);
title('log transformation');



