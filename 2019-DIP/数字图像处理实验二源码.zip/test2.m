%% ��ʼ��
clc;
clear all;
close all;
%% ����ͼ������
img_gray=imread('Fig_fractured_spine.tif');
figure;
subplot(3,3,1);
imshow(img_gray);
title('original');

%% ���ɱ任
img_t1=double(img_gray);
c=1;
pow=0.1;

for  pow =0.1:0.1:0.8
       img_t2=im2uint8(mat2gray(img_t1.^pow));
       c=c+1;
       subplot(3,3,c);
       imshow(img_t2);
       gamma=sprintf('power-law:gamma=%.1f',pow);
       title(gamma);
end
