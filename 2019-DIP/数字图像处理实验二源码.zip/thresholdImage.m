function The_moon=thresholdImage()
    
    ave_bw=ave/256;

bw_moon=im2bw(gray_moon,ave_bw);

end