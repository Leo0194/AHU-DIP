%% ��ʼ��
clc
clear all;
close all;
%% ����ͼƬ
I=imread('Fig_test_pattern_blurring_orig.tif');
subplot(2,3,1);
imshow(I);
title("ԭͼ");

%% �����˲���Ȼ���ٽ��пռ��˲�
h1=fspecial('average',[3,3]);
h2=fspecial('average',[5,5]);
h3=fspecial('average',[9,9]);
h4=fspecial('average',[15,15]);
h5=fspecial('average',[35,35]);


%% �õ��˲�ͼ��
im1=imfilter(I,h1);
subplot(2,3,2);
imshow(im1);
title("mask of 3*3");

im2=imfilter(I,h2);
subplot(2,3,3);
imshow(im2);
title("mask of 5*5");

im3=imfilter(I,h3);
subplot(2,3,4);
imshow(im3);
title("mask of 9*9");

im4=imfilter(I,h4);
subplot(2,3,5);
imshow(im4);
title("mask of 15*15");

im5=imfilter(I,h5);
subplot(2,3,6);
imshow(im5);
title("mask of 35*35");

