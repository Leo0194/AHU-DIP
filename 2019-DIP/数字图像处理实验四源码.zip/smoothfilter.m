function smoothfilter()

%% 
clc
clear all;
close all;

%% 
I=imread('lena.jpg');
subplot(1,2,1);
imshow(I);
title("ԭͼ");

%% ��ֵƽ���˲�
f1=fspecial('average',[5,5])
img1=imfilter(I,f1);
subplot(1,2,2);
imshow(img1);
title("��ֵ�˲���");

end