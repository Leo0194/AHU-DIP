function histogram()
        %%
        clc
        clear all
        close all
        %%
        I=imread('pollen.jpg');
        [row,column]=size(I);
        array=zeros(1,256);
        
        for i=1:row
            for j=1:column
                
                
                array(1+I(i,j)+1)=array(1+I(i,j)+1)+1;     %ͳ�Ƹ����ص�ĻҶ�ֵ
                
            end
        end
i=1:256;

figure
subplot(1,2,1)
imshow(I);
title('��ͳ��ͼ��');
subplot(1,2,2);
bar(i,array(1,i));
title('�Զ���ͳ�ƻҶ�ֵ');
end
