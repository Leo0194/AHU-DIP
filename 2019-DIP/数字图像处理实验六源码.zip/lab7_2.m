%% 
clc
clear all
close all;

%% 
I=imread('tropical_rain_grayscale.tif');
slice=[32 64 96 128 160 192];
Q=grayslice(I,slice);
figure;
mymap=[0 0 0;
                0 0 1;     %��ɫ
                0 1 0;
                1 0 0;
                0 1 1;     
                1 1 0;
                1 0 1;
                1 1 1;]
imshow(Q,colormap(mymap));