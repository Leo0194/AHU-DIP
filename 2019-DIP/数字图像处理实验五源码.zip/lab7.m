%% ��ʼ��
clc
clear all;
close all;

%%
Img=imread('top_ left_flower.tif');
I=(Img(:,:,1)+Img(:,:,2)+Img(:,:,3))/3.0;
%I2=rgb2gray(Img);
imshow(I);